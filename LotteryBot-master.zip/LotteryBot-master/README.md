# Telegram 群组抽奖机器人

### [抽奖机器的人环境与配置](https://github.com/tingv/LotteryBot/wiki)

![后台截图](https://user-images.githubusercontent.com/47696436/58376889-5b53df00-7fa7-11e9-8a4e-aaad564fa7f4.png)
