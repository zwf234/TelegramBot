<?php
// +----------------------------------------------------------------------
// | 海豚PHP框架 [ DolphinPHP ]
// +----------------------------------------------------------------------
// | 版权所有 2016~2019 广东卓锐软件有限公司 [ http://www.zrthink.com ]
// +----------------------------------------------------------------------
// | 官方网站: http://dolphinphp.com
// +----------------------------------------------------------------------

return [
    // 产品信息
    'product_name'      => 'DolphinPHP',
    'product_version'   => '1.4.0',
    'build_version'     => '201902242038',
    'product_website'   => 'http://www.dolphinphp.com',
    'product_update'    => 'http://www.dolphinphp.com/checkUpdate',
    'develop_team'      => 'DolphinPHP',

    // 公司信息
    'company_name'    => '广东卓锐软件有限公司',
    'company_website' => 'http://www.zrthink.com',
];