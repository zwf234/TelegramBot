-- -----------------------------
-- 导出时间 `2019-05-25 21:31:13`
-- -----------------------------
DROP TABLE IF EXISTS `dp_crontab`;
DROP TABLE IF EXISTS `dp_crontab_log`;
