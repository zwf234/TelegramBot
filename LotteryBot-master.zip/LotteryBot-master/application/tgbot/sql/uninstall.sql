-- -----------------------------
-- 导出时间 `2019-05-25 21:31:06`
-- -----------------------------
DROP TABLE IF EXISTS `dp_tgbot_chat`;
DROP TABLE IF EXISTS `dp_tgbot_conversation`;
DROP TABLE IF EXISTS `dp_tgbot_lottery`;
DROP TABLE IF EXISTS `dp_tgbot_lottery_channel`;
DROP TABLE IF EXISTS `dp_tgbot_lottery_prize`;
DROP TABLE IF EXISTS `dp_tgbot_lottery_user`;
