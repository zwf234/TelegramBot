<?php
return [
    // Hashids 配置
    'hashids' => [
        'salt' => 'xstorebot',  // 盐
        'min_hash_length' => 16, // 最小长度
    ],
];